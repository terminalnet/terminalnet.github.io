<?php
  $myfile = fopen("arquivo.markdown", "r") or die("Não deu para abrir o arquivo.");
  echo fread($myfile,filesize("arquivo.markdown"));
  fclose($myfile);
